#ifndef SL_MEMORY_CONFIG_H
#define SL_MEMORY_CONFIG_H

#include "sl_memory_manager_region_config.h"
#include "sl_common.h"

#ifndef SL_SUPPRESS_DEPRECATION_WARNINGS_SDK_2024_6
#warning "This file is deprecated as of Simplicity SDK 2024.6. Content was moved to sl_memory_manager_region_config.h."
#endif

#endif
