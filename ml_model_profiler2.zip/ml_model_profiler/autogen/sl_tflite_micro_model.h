// Auto-generated serialization of TFLite flatbuffers in config directory
#ifndef SL_TFLITE_MICRO_MODEL_H
#define SL_TFLITE_MICRO_MODEL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

extern const uint8_t sl_tflite_model_array[];
extern const uint32_t sl_tflite_model_len;

#ifdef __cplusplus
}
#endif

#endif // SL_TFLITE_MICRO_MODEL_H
