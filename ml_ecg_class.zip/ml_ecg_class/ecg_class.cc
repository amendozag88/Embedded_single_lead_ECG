/***************************************************************************//**
 * @file
 * @brief Initalization and main functionality for application
 *******************************************************************************
 * # License
 * <b>Copyright 2022 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include <ecg_class.h>
#include "constants.h"
#include "predictor.h"
#include "sl_tflite_micro_model.h"
#include "sl_tflite_micro_init.h"
#include "sl_sleeptimer.h"
#include "sl_status.h"
#include "sl_led.h"
#include "sl_simple_led_instances.h"
#include <cstdio>

#include "input_data.h"

static int input_length;
static volatile bool inference_timeout;
static sl_sleeptimer_timer_handle_t inference_timer;
static sl_sleeptimer_timer_handle_t led_timer;
static TfLiteTensor* model_input;
static tflite::MicroInterpreter* interpreter;

static int input_start = 0;

// Triggered by the inference_timer
static void on_timeout_inference(sl_sleeptimer_timer_handle_t *handle, void* data)
{
  (void)handle; // unused
  (void)data; // unused
  inference_timeout = true;
}

// Triggered by the led_timer
void on_timeout_led(sl_sleeptimer_timer_handle_t *led_timer, void *data)
{
  (void)led_timer; // unused
  (void)data; // unused
  sl_led_turn_off(&sl_led_led0);
  sl_led_turn_off(&sl_led_led1);
}

void ecg_class_init(void)
{
  printf("ECG Classification\n");
  printf("init..\n");
  // Obtain pointer to the model's input tensor.
  model_input = sl_tflite_micro_get_input_tensor();
  interpreter = sl_tflite_micro_get_interpreter();
  if ((model_input->dims->size != 4) || (model_input->dims->data[0] != 1)
      || (model_input->dims->data[1] != SEQUENCE_LENGTH)
      || (model_input->dims->data[2] != ECG_CHANNELS)
      || (model_input->type != kTfLiteFloat32)) {
    printf("error: bad input tensor parameters in model\n");
    EFM_ASSERT(false);
    return;
  }

  input_length = model_input->bytes / sizeof(float);

  //sl_status_t setup_status = accelerometer_setup();

//  if (setup_status != SL_STATUS_OK) {
//    printf("error: accelerometer setup failed\n");
//    EFM_ASSERT(false);
//    return;
//  }

  // Waiting for accelerometer to become ready
//  while (true) {
//    sl_status_t status = accelerometer_read(NULL, 0);
//    if (status == SL_STATUS_OK) {
//      break;
//    }
//  }

  inference_timeout = false;
  sl_sleeptimer_start_periodic_timer_ms(&inference_timer, INFERENCE_PERIOD_MS, on_timeout_inference, NULL, 0, 0);
  printf("ready\n");
}


// Prints classification result and light up LED.
static void handle_output(int categ)
{
  uint32_t ts = sl_sleeptimer_tick_to_ms(sl_sleeptimer_get_tick_count());

  if (categ == NORMAL) {
    printf("t=%lu detection=NORMAL (0)\n", ts);
    sl_led_turn_on(&sl_led_led0);
    sl_sleeptimer_start_timer_ms(&led_timer,
                                 TOGGLE_DELAY_MS,
                                 on_timeout_led, NULL,
                                 0,
                                 SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == OTHER) {
    printf("t=%lu detection=OTHER (1)\n", ts);
    sl_led_turn_on(&sl_led_led0);
    sl_sleeptimer_start_timer_ms(&led_timer,
                                 TOGGLE_DELAY_MS,
                                 on_timeout_led, NULL,
                                 0,
                                 SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == LBBB) {
    printf("t=%lu detection=LBBB (2)\n", ts);
    sl_led_turn_on(&sl_led_led0);
    sl_sleeptimer_start_timer_ms(&led_timer,
                                 TOGGLE_DELAY_MS,
                                 on_timeout_led, NULL,
                                 0,
                                 SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == RBBB) {
      printf("t=%lu detection=RBBB (3)\n", ts);
      sl_led_turn_on(&sl_led_led0);
      sl_sleeptimer_start_timer_ms(&led_timer,
                                   TOGGLE_DELAY_MS,
                                   on_timeout_led, NULL,
                                   0,
                                   SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == PVC) {
      printf("t=%lu detection=PVC (4)\n", ts);
      sl_led_turn_on(&sl_led_led0);
      sl_sleeptimer_start_timer_ms(&led_timer,
                                   TOGGLE_DELAY_MS,
                                   on_timeout_led, NULL,
                                   0,
                                   SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == CHF) {
      printf("t=%lu detection=CHF (5)\n", ts);
      sl_led_turn_on(&sl_led_led0);
      sl_sleeptimer_start_timer_ms(&led_timer,
                                   TOGGLE_DELAY_MS,
                                   on_timeout_led, NULL,
                                   0,
                                   SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == MI) {
      printf("t=%lu detection=MI (6)\n", ts);
      sl_led_turn_on(&sl_led_led0);
      sl_sleeptimer_start_timer_ms(&led_timer,
                                   TOGGLE_DELAY_MS,
                                   on_timeout_led, NULL,
                                   0,
                                   SL_SLEEPTIMER_NO_HIGH_PRECISION_HF_CLOCKS_REQUIRED_FLAG);
  } else if (categ == NO_CLASS) {
    // No class detected
  }
}

void ecg_class_loop(void)
{
  //Takes in 187 values of input_data at a time (since input size of model is n*187 and output size is n*1, where n is number of data points)
  float arr[187] = {0}; // All elements initialized to 0

  for (int i = 0; i < 187; i++) {
      arr[i] = input_data[input_start+i];
  }
  memcpy(model_input->data.f, arr, model_input->bytes);
  input_start += 187;

  // If there was no new data, wait until next time.
//  if (status == SL_STATUS_FAIL) {
//    return;
//  }
  int input_size = sizeof(input_data) / sizeof(input_data[0]);
  if (input_start >= input_size) {
      return;
  }

  // Inference is triggered periodically by a timer
  if (inference_timeout) {
    inference_timeout = false;

    TfLiteStatus invoke_status = interpreter->Invoke();

    if (invoke_status != kTfLiteOk) {
      printf("error: inference failed\n");
      return;
    }

    // Analyze the results to obtain a prediction. config>tflite>"model_ffb5.tflite" is a downsized (20kB) version of "inferenceV2.ipynb" file from Antonio (lower accuracy).
    const model_output_t *output = (const model_output_t *)interpreter->output(0)->data.f;
    int ecg_class = predict_class(output);

    // Produce an output
    handle_output(ecg_class);
  }
}

